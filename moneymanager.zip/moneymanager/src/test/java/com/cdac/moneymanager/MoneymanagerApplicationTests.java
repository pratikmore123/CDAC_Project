package com.cdac.moneymanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneymanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
